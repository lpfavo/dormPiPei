from django.urls import path
from.import views

urlpatterns=[
    path('login/', views.login_page, name='login_page'),
    path('test/', views.test_page, name="test_page,"),
    #path('info/', views.info_page, name="info_page,"),
    path('info/', views.getbasicInfo, name="getbasicInfo"),
    path('getinfo/', views.getInfomation, name="getInfomation")
]
