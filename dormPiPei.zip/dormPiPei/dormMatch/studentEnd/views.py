from django.shortcuts import render
from . import models
from django.contrib import auth
from django.contrib.auth.decorators import login_required
import datetime
from django.views.decorators.csrf import csrf_exempt, csrf_protect


# Create your views here.
# @login_required(login_url='index')
def login_page(request):
    return render(request, 'studentEnd/login_page.html')


# @login_required(login_url='index')
def test_page(request):
    return render(request, 'studentEnd/test.html')


def info_page(request):
    return render(request, 'studentEnd/info_page.html')

# def nanlv(request):
#     return render(request,'studentEnd/男绿.png')

# @login_required(login_url='index')
def getbasicInfo(request):
    name = request.POST.get('name')
    school = request.POST.get('school')
    studentID = request.POST.get('studentID')
    #right = models.StudentInfomation.objects.filter(studentName__exact=name,school__exact=school,studentID__exact=studentID)
    #if right!=[]:
    print(name,school,studentID)
    return render(request, 'studentEnd/info_page.html',)
    # else:
    #     return render(request, 'studentEnd/index.html',{'errmsg': '用户不存在'})
    # user = auth.authenticate(username=name, password=studentID)
    # if user is not None and user.is_active:
    #     auth.login(request, user)
    #     return render(request, 'studentEnd/info_page.html')
    # else:
    #     return render(request, 'studentEnd/index.html', {'errmsg': '用户不存在'})


# @login_required(login_url='index')
def stuInfo(request):
    school = request.POST.get('school')
    name = request.POST.get('name')
    sex = request.POST.get('sex')
    studentID = request.POST.get('studentID')
    major = request.POST.get('major')
    addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.school = school
    student.studentName = name
    student.sex = sex
    student.major = major
    student.addTime = addtime
    student.save()

    majorModify = models.Major.objects.get(school=school, major=major)
    if sex == True:
        majorModify.maleNumber = majorModify.getMaleNumber() + 1
    else:
        majorModify.femaleNumber = majorModify.getFemaleNumber() + 1
    majorModify.save()


# @login_required(login_url='index')
# def getSleepTime(request, studentID):
#     student = models.StudentInfomation.objects.get(pk=studentID)
#     sleepTime = request.POST.get('sleepTime')
#     wakeTime = request.POST.get('wakeTime')
#     sleepWeight = request.POST.get('sleepWeight')
#     sl_id = models.SleepTime.objects.filter(sleepTime=sleepTime,wakeTime=wakeTime,sleepWeight=sleepWeight)
#     student.sleepTime = sl_id[0]
#     student.save()


# @login_required(login_url='index')
def getStudentsProvince(request, studentID):
    studentProvince = request.POST.get('studentProvince')
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.studentProvince=studentProvince
    student.save()


# @login_required(login_url='index')
def getSports(request, studentID):
    student = models.StudentInfomation.objects.get(pk=studentID)
    sports = request.POST.get('sports')
    sportWeight = request.POST.get('sportWeight')
    sp_id = models.Sports.objects.filter(sports=sports,sportsWeight=sportWeight)
    student.sports = sp_id[0]
    student.save()


# @login_required(login_url='index')
def getInnerSensitivity(request, studentID):
    innerSensitivity = request.POST.get('innerSensitivity')
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.innerSensitivity = innerSensitivity
    student.save()


# @login_required(login_url='index')
def getNovel(request, studentID):
    student = models.StudentInfomation.objects.get(pk=studentID)
    novelType = request.POST.get('novelType')
    novelTypeWeight = request.POST.get('novelTypeWeight')
    no_id = models.Novel.objects.filter(novelType=novelType,novelTypeWeight=novelTypeWeight)
    student.novelType = no_id[0]
    student.save()


# @login_required(login_url='index')
# def getTVShow(request, studentID):
#     # tvShowTypeWeight = request.POST.get('tvTypeWeight')
#     # addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#     # models.TVShow.objects.create(tvShowType=tvShowType, tvShowTypeWeight=tvShowTypeWeight, studentID=studentID,addTime=addtime)
#     student = models.StudentInfomation.objects.get(pk=studentID)
#     tvShowType = request.POST.get('tvType')
#     tvShowTypeWeight = request.POST.get('tvShowTypeWeight')
#     tv_id = models.TVShow.objects.filter(tvShowType=tvShowType,tvShowTypeWeight=tvShowTypeWeight)
#     student.tvShowType = tv_id[0]
#     student.save()


# @login_required(login_url='index')
# def getAircondition(request, studentID):
#     student = models.StudentInfomation.objects.get(pk=studentID)
#     summerTemperature = request.POST.get('summertemperature')
#     winterTemperature = request.POST.get('wintertemperature')
#     temperatureWeight = request.POST.get('temperatureWeight')
#     temp_id = models.AirconditionTemperature.objects.filter(summertemperature=summerTemperature,wintertemperature=winterTemperature,temperatureWeight=temperatureWeight)
#     student.airconditionTemperature=temp_id[0]
#     student.save()


# @login_required(login_url='index')
# def getSmoking(request, studentID):
#     student = models.StudentInfomation.objects.get(pk=studentID)
#     smoke = request.POST.get('smoke')
#     smokeWeight = request.POST.get('smokeWeight')
#     sm_id = models.Smoking.objects.filter(smoke=smoke, smokeWeight=smokeWeight)
#     student.smoke = sm_id[0]
#     student.save()


# @login_required(login_url='index')
#@csrf_protect
def getInfomation(request):
    # 学生基本信息 密码与学号已知  姓名专业可能也已知
    school = request.POST.get('school')
    studentName = request.POST.get('studentName')
    sex = request.POST.get('sex')
    studentID = request.POST.get('studentID')
    major = request.POST.get('major')
    addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
 #   # student = models.StudentInfomation.objects.get(pk=studentID)
    # student.school = school
    # student.studentName = studentName
    # student.sex = sex
    # student.major = major
#    # student.addTime = addtime
    print("school: ",school)
    print("studentName: ",studentName)
    print("sex: ",sex)
    print("studentID: ", studentID)
    print("major: ", major)
    print("addtime: ", addtime)

 #   # majorModify = models.Major.objects.get(school=school, major=major)
    # if sex:
    #     majorModify.maleNumber = majorModify.getMaleNumber() + 1
    # else:
    #     majorModify.femaleNumber = majorModify.getFemaleNumber() + 1
  #  # majorModify.save()

    # 学生省份南北方信息及内心敏感度
    studentProvince = request.POST.get('studentProvince')
    ##student.studentProvince = studentProvince
    southNorth = request.POST.get('southNorth')
    southNorthWeight= request.POST.get('southNorthWeight')
    # s_id=models.SouthNorth.objects.filter(southNorth=southNorth,southNorthWeight=southNorthWeight)
    # student.southNorth=s_id[0]
    ##student.southNorth=southNorth
    ##student.southNorthWeight=southNorthWeight
    innerSensitivity = request.POST.get('innerSensitivity')
    ##student.innerSensitivity = innerSensitivity
    print("studentProvince: ", studentProvince)
    print("southNorth: ", southNorth)
    print("southNorthWeight: ", southNorthWeight)
    print("innerSensitivity: ", innerSensitivity)


    # 学生睡眠信息
    sleepTime = request.POST.get('sleepTime')
    wakeTime = request.POST.get('wakeTime')
    ###sleepWeight = request.POST.get('sleepWeight')
    # sl_id = models.SleepTime.objects.filter(sleepTime=sleepTime,wakeTime=wakeTime,sleepWeight=sleepWeight)
    ##student.sleepTime = sleepTime
    ##student.wakeTime=wakeTime
    ###student.sleepWeight=sleepWeight
    print("sleepTime: ", sleepTime)
    print("wakeTime: ", wakeTime)

    # 学生运动信息
    sports = request.POST.get('sports')
    sportsWeight = request.POST.get('sportsWeight')
    # sp_id = models.Sports.objects.filter(sports=sports,sportsWeight=sportWeight)
    # student.sports = sp_id[0]
    for sp in sports:
        print("sports: ", sp)
    ##     student.sports.add(sp)
    ##student.sports=sports
    ##student.sportsWeight=sportsWeight

    print("sportsWeight: ", sportsWeight)

    # 学生喜爱阅读的小说类型
    novelType = request.POST.get('novelType')
    novelTypeWeight = request.POST.get('novelTypeWeight')
    # no_id = models.Novel.objects.filter(novelType=novelType,novelTypeWeight=novelTypeWeight)
    # student.novelType = no_id[0]
    #student.novelType=novelType
    for no in novelType:
    ##     student.novelType.add(no)
    ## student.novelTypeWeight=novelTypeWeight
        print("novelType: ", no)
    print("novelTypeWeight: ", novelTypeWeight)

    # 学生喜欢观看的电视剧类型
    # tvShowType = request.POST.get('tvType')
    # tvShowTypeWeight = request.POST.get('tvShowTypeWeight')
    # tv_id = models.TVShow.objects.filter(tvShowType=tvShowType,tvShowTypeWeight=tvShowTypeWeight)
    # student.tvShowType = tv_id[0]
    # student.tvShowType=tvShowType
    # for ts in tvShowType:
    #     student.novelType.add(ts)
    # student.tvShowTypeWeight=tvShowTypeWeight

    # 学生认为空调的合适温度
    summerTemperature = request.POST.get('summerTemperature')
    winterTemperature = request.POST.get('winterTemperature')
    #temperatureWeight = request.POST.get('temperatureWeight')
    # temp_id = models.AirconditionTemperature.objects.filter(summertemperature=summerTemperature,wintertemperature=winterTemperature,temperatureWeight=temperatureWeight)
    # student.airconditionTemperature=temp_id[0]
    ##student.summerairconditionTemperature=summerTemperature
    ##student.winterairconditionTemperature=winterTemperature
    #student.temperatureWeight=temperatureWeight
    print("summerTemperature: ", summerTemperature)
    print("winterTemperature: ", winterTemperature)


    # 学生吸烟信息
    smoke = request.POST.get('smoke')
    smokeWeight = request.POST.get('smokeWeight')
    # sm_id = models.Smoking.objects.filter(smoke=smoke,smokeWeight=smokeWeight)
    # student.smoke = sm_id[0]
    ##student.smoke=smoke
    ##student.smokeWeight=smokeWeight
    ##student.save()
    print("smoke: ", smoke)
    print("smokeWeight: ", smokeWeight)
    return render(request, 'studentEnd/test.html')
