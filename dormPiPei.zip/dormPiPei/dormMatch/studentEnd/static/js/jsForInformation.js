
information_male_logo = $("#male+label img");
information_female_logo = $("#female+label img");
information_male = $("#male");
information_female = $("#female");
information_male[0].addEventListener("change",function(){
  // console.log("change male");
  if(information_male[0].checked)
  {
    information_male_logo[0].src="/static/images/personalInfo/maleGreen.png";
    information_female_logo[0].src="/static/images/personalInfo/femaleGray.png";
  }
  else
  {
    information_male_logo[0].src="/static/images/personalInfo/maleGray.png";
    information_female_logo[0].src="/static/images/personalInfo/femaleRed.png";
  }
},false)

information_female[0].addEventListener("change",function(){
  // console.log("change female");
  if(information_female[0].checked)
  {
      information_male_logo[0].src="/static/images/personalInfo/maleGray.png";
      information_female_logo[0].src="/static/images/personalInfo/femaleRed.png";
  }
  else
  {
      information_male_logo[0].src="/static/images/personalInfo/maleGreen.png";
      information_female_logo[0].src="/static/images/personalInfo/femaleGray.png";
  }
},false)
//--------------------------------------------------------------------------------------
information_button = $(".information_button");
information_button[0].addEventListener("touchstart",function(){
  $(".information").hide(500);
  $(".sleep").show(500);
},false);
//------------------------------------------------------------------------------------------
information_range = $("#information_range");
information_range[0].addEventListener("change",function(){
  // console.log(typeof(information_range[0].value));
  // console.log(information_range[0].style.backgroundSize);
  switch (information_range.val()) {
    case '0':
      // console.log("here");
      information_range.css("backgroundSize","0% 100%");
      break;
    case '1':
      information_range.css("backgroundSize","20% 100%");
      break;
    case '2':
      information_range.css("backgroundSize","40% 100%");
      break;
    case '3':
      information_range.css("backgroundSize","60% 100%");
      break;
    case '4':
      information_range.css("backgroundSize","80% 100%");
      break;
    case '5':
      information_range.css("backgroundSize","100% 100%");
      break;
    default:
      // console.log("there");
  }
},false);

//______________________________________________________________________专业选择下拉框
let major_choose_detail = $(".major_choose_detail");
let major_choose = $(".major_choose");
let major = $("#major_choose");
let major_text = $("#major_choose p")
major[0].addEventListener("touchstart",function(){
    major_choose.slideToggle();
},false);
for (let i = 0; i < major_choose_detail.length; i++) {
  major_choose_detail[i].addEventListener('touchstart',function(){
      major_text.text(major_choose_detail[i].innerHTML);
  },false)
}
//________________________________________________________________________________
let n_o_s = $("#n_o_s");
let area_choose = $("#area_choose");
let area_choose_detail = $(".area_choose_detail");
let n_o_s_text = $("#n_o_s p")
n_o_s[0].addEventListener("touchstart",function(){
  area_choose.slideToggle();
},false);
for(let i = 0 ; i < area_choose_detail.length;i++){
  area_choose_detail[i].addEventListener("touchstart",function(){
    n_o_s_text.text(area_choose_detail[i].innerHTML);
  },false);
}


let province = $("#province");
let s_province = $("#s_province");
let n_province = $("#n_province");
let p_choose = $(".p_choose");
let province_text = $("#province p");
province[0].addEventListener("touchstart",function(){
  if(n_o_s_text.text()=="南方")
  {
    s_province.slideDown();
  }
  if(n_o_s_text.text()=="北方")
  {
    n_province.slideDown();
  }
},false);
for(let i = 0 ; i < p_choose.length;i++){
  p_choose[i].addEventListener("touchend",function(){
    province_text.text(p_choose[i].innerHTML);
  },false);
  p_choose[i].addEventListener("click",function(){

      if(n_o_s_text.text()=="南方")
      {
        s_province.slideUp();
      }
      if(n_o_s_text.text()=="北方")
      {
        n_province.slideUp();
      }
  },false);
}
