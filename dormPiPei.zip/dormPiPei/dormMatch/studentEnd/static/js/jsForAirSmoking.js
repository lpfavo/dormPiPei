smoking_range = $("input[name='smoking_range']");
smoking_range[0].addEventListener("change",function(){
  // console.log(typeof(smoking_range[0].value));
  // console.log(smoking_range[0].style.backgroundSize);
  switch (smoking_range.val()) {
    case '0':
      // console.log("here");
      smoking_range.css("backgroundSize","0% 100%");
      break;
    case '1':
      smoking_range.css("backgroundSize","20% 100%");
      break;
    case '2':
      smoking_range.css("backgroundSize","40% 100%");
      break;
    case '3':
      smoking_range.css("backgroundSize","60% 100%");
      break;
    case '4':
      smoking_range.css("backgroundSize","80% 100%");
      break;
    case '5':
      smoking_range.css("backgroundSize","100% 100%");
      break;
    default:
      // console.log("there");
  }
},false);
//_______________________________________________________________________
 smoking_true = $('#smoking_true+label div');
 smoking_false = $('#smoking_false+label div');
 smoking_true[0].addEventListener('touchstart',function(){
   if(smoking_true[0].style.transform!=="scale(1)")
    {
      smoking_true[0].style.transform="scale(1)";
      smoking_true[0].style.transform="scale(2)";
    }
   else {
    smoking_true[0].style.transform="scale(2)";
    smoking_false[0].style.transform="scale(1)";
   }

 },false);
 smoking_false[0].addEventListener('touchstart',function(){
   if(smoking_false[0].style.transform!=="scale(1)")
    {
      smoking_false[0].style.transform="scale(1)";
      smoking_true[0].style.transform="scale(2)";
    }
   else {
     smoking_false[0].style.transform="scale(2)";
     smoking_true[0].style.transform="scale(1)";
   }
 },false);
 //________________________________________________________________________________
 let submit_button = $("#submit_button");
 let book_choose_img = $(".book_fu img");
 let book_title = $(".book_fu p");
 let books = [];

 submit_button.click(function(){
   for (let i = 0; i < book_choose_img.length; i++) {
     if(book_choose_img[i].src.match("Group.png") && i%2 == 0)
      books[books.length] = book_title.text();
   }
   $.ajax({
    type:"post",
    url:"/studentEnd/getinfo/",
    data:{"school":$("input[name='school']").val(),
            "studentName":$("input[name='studentName']").val(),
            "studentID":$("input[name='studentID']").val(),
            "major":$("#major p").text(),
            "sex":$("input[name='sex']").val(),
            "southNorth":$("#n_o_s p").text(),
            "studentProvince":$("#province p").text(),
            "innerSensitivity":$("#information_range").val(),
            "sleepTime":$(".sleep_setTime2 p").text(),
            "wakeTime":$(".sleep_setTime1 p").text(),
            "sports":$("input[name='sportsTypes']").val(),
            "sportsWeight":3,
            "novelType":books,
            "novelTypeWeight":4,
            "winterTemperature":30,
            "summerTemperature":16,
            "smoke":1,
            "smokeWeight":5,},
         async:true,
         success:function(data){
           alert('提交成功');
           if(data.status==302)
            location.url = data.url;
         },
         error:function(XMLHttpRequest,textStatus,errorThrown){}
   });
 })
