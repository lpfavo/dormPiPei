//运动选择点切换
var sportChoose = $(".sport_picture");
sportChoose[0].addEventListener("touchstart",function(ev){
  var ev = ev || window.event;
  var target = ev.target || ev.srcElement;
  if(target.nodeName.toLowerCase() == 'img'){
    if(target.src.match("8.png"))
      target.src="/static/images/sport/selectFrameCopy4.png";
    else
      target.src="/static/images/sport/selectFrameCopy8.png";
  }

},false)
//值选择
sport_range = $("#sport_range");
sport_range[0].addEventListener("change",function(){
    switch (sport_range.val()) {
      case '0':
        sport_range.css("backgroundSize","0% 100%");
        break;
      case '1':
        sport_range.css("backgroundSize","20% 100%");
        break;
      case '2':
        sport_range.css("backgroundSize","40% 100%");
        break;
      case '3':
        sport_range.css("backgroundSize","60% 100%");
        break;
      case '4':
        sport_range.css("backgroundSize","80% 100%");
        break;
      case '5':
        sport_range.css("backgroundSize","100% 100%");
        break;
      default:

    }
},false)

sport_button = $('.sport_button');
sport = $(".sport");
book = $(".game");
sport_button[0].addEventListener('touchstart',function(){
  sport.hide(500);
  book.show(500);
},false)
