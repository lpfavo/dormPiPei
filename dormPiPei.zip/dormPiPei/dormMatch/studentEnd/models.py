from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class School(models.Model):
    '''
    学校信息
    '''
    school = models.CharField(db_column="学校", max_length=20, null= False, primary_key=True)
    schoolProvince = models.CharField(db_column="学校省份", max_length=20, null= True,)
    remark = models.TextField(db_column="备注", null=True)
    addTime = models.DateTimeField(db_column="学校信息添加时间", null= True, blank=False)


# 通过views函数进行修改，每增加一个或删除一个时，获取已有数据，修改后专业的性别人数，再更新
class Major(models.Model):
    '''
    学校专业信息
    '''
    school = models.ForeignKey(School, null= True,on_delete=models.CASCADE, db_column="学校")
    major = models.CharField(db_column="专业", max_length=20, null= False, blank=False,primary_key=True)
    maleNumber = models.IntegerField(db_column="男生人数", default=0)
    femaleNumber = models.IntegerField(db_column="女生人数", default=0)
    addTime = models.DateTimeField(db_column="专业信息添加时间", null= True, blank=False)


# class SleepTime(models.Model):
#     '''
#     学生睡觉时间信息
#     '''
#     sl_id = models.AutoField(primary_key=True)
#     wakeTime = models.CharField(db_column="起床时间", null=False, blank=False)
#     sleepTime = models.CharField(db_column="睡觉时间", null= False, blank=False)
#     addTime = models.DateTimeField(db_column="睡觉信息添加时间", null= True, blank=False)


# class SouthNorth(models.Model):
#     '''
#     学生所在地南北方信息
#     '''
#     sn_id=models.AutoField(primary_key=True)
#     southNorth = models.BooleanField(db_column="南北方", null= True, blank=False)
#     addTime = models.DateTimeField(db_column="南北方信息添加时间", null= True, blank=False)


class Sports(models.Model):
    '''
    学生运动信息
    '''
    SPORTS_CHOICES =(
        ( 1, "跑步"),
        ( 2, "羽毛球"),
        ( 3, "篮球"),
        ( 4, "足球"),
        ( 5, "自行车"),
        ( 6, "游泳"),
        ( 7, "撸铁"),
        ( 8, "兵乓球"),
        ( 9, "瑜伽舞蹈"),
    )
    sp_id=models.AutoField(primary_key=True)
    sports = models.IntegerField(db_column="运动", null= False, choices=SPORTS_CHOICES, blank=False)
    addTime = models.DateTimeField(db_column="运动信息添加时间", null= True, blank=False)


class Novel(models.Model):
    '''
    学生阅读小说类型信息
    '''
    NOVEL_CHOICES=(
        (1, "技术知识类"),
        (2, "文学类小说"),
        (3, "漫画"),
        (4, "言情小说"),
        (5, "玄幻小说"),
        (6, "科幻小说"),
        (7, "武侠小说"),
        (8, "推理小说"),
        (9, "恐怖小说"),
        (10, "网游小说"),
        (11, "二次元小说"),

    )
    no_id=models.AutoField(primary_key=True)
    novelType = models.IntegerField(db_column="小说类型", null=False, blank=False, choices=NOVEL_CHOICES)#多选问题
    addTime = models.DateTimeField(db_column="小说类型信息添加时间", null= True, blank=False)

#保留
# class TVShow(models.Model):
#     '''
#     学生看剧类型信息
#     '''
#     TVSHOW_CHOICES=(
#         (1, "游戏类直播"),
#         (2, "唱歌类直播"),
#         (3, "短视频"),
#         (4, "日韩"),
#         (5, "欧美"),
#         (6, "综艺"),
#     )
#     no_id=models.AutoField(primary_key=True)
#     tvShowType = models.IntegerField(db_column="看剧类型", null= False, choices = TVSHOW_CHOICES，blank=False)#0-
#     tvShowType = models.CharField(db_column="看剧类型", null=True, blank=False, max_length=30)
#     addTime = models.DateTimeField(db_column="看剧类型信息添加时间", null= True, blank=False)


# class AirconditionTemperature(models.Model):
#     '''
#     冬夏空调温度信息
#     '''
#     temp_id = models.AutoField(primary_key=True)
#     wintertemperature = models.IntegerField(db_column="冬天温度", null=False, blank=False)
#     summertemperature = models.IntegerField(db_column="夏天空调温度", null=False, blank=False)
#     addTime = models.DateTimeField(db_column="夏天空调温度添加时间", null=True, blank=False)


# class Smoking(models.Model):
#     '''
#     学生吸烟信息
#     '''
#     sm_id = models.AutoField(primary_key=True)
#     smoke = models.BooleanField(db_column="吸烟", null= False, blank=False)#0不吸烟 1吸烟
#     addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)


class StudentInfomation(models.Model):
    '''
    学生基本信息
    '''
    studentID = models.CharField(db_column="学生学号", max_length=8, primary_key=True, null=False, blank=False)
    #user = models.OneToOneField(User, on_delete=models.CASCADE, db_column="用户")
    studentName = models.CharField(db_column="学生姓名", max_length=20, null=True, blank=False)
    sex = models.BooleanField(db_column="性别", null=True, blank=False)  # 男true 女false？
    school = models.CharField(db_column="学校", max_length=20, null=True, blank=False)
    major = models.ForeignKey(Major,null=True,on_delete=models.CASCADE, db_column="学生专业",)
    studentClass = models.CharField(db_column="学生班级", max_length=20, null=True, blank=False)
    loginPassword = models.CharField(db_column="登录密码", max_length=20, null=True, blank=False)
    studentProvince = models.CharField(db_column="学生省份",max_length=3,null=True,blank=False)

    southNorth=models.CharField(db_column="南北方",null=True,blank=False,max_length=3)
    southNorthWeight = models.IntegerField(db_column="南北方权重", null= True, blank=False)#01
    innerSensitivity = models.IntegerField(null=True, blank=False, db_column="内心敏感度")

    sports = models.ManyToManyField(Sports, blank=False, db_column="运动")
    sportsWeight = models.IntegerField(db_column="运动权重", null=True, blank=False)
    novelType = models.ManyToManyField(Novel,db_column="小说类型", blank=True)
    novelTypeWeight = models.IntegerField(db_column="小说类型权重", null= True, blank=False)
    #tvShowType = models.ManyToManyField(TvShow,db_column="看剧类型", null= True, blank=False)
    #tvShowTypeWeight = models.IntegerField(db_column="看剧类型权重", null= True, blank=False)

    winterairconditionTemperature = models.IntegerField(db_column="冬天空调合适温度", null= True, blank=False)
    summerairconditionTemperature = models.IntegerField(db_column="夏天空调合适温度", null=True, blank=False)
    #temperatureWeight = models.IntegerField(db_column="空调温度权重", null=True, blank=False)
    sleepTime = models.IntegerField(db_column="睡觉时间",null= True, blank=True)
    wakeTime = models.IntegerField(db_column="起床时间",null= True, blank=True)
    #sleepWeight = models.IntegerField(db_column="睡眠重要性权重",null= True, blank=False)#1-5
    smoke = models.IntegerField(db_column="吸烟",null= True,blank=True)
    smokeWeight = models.IntegerField(db_column="吸烟权重", null= True, blank=False)
    addTime = models.DateTimeField(db_column="学生信息添加时间", null= True, blank=False)
