from django.apps import AppConfig


class StudentendConfig(AppConfig):
    name = 'studentEnd'
